from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.boxlayout import BoxLayout



class EndScreen(AnchorLayout):
    pass