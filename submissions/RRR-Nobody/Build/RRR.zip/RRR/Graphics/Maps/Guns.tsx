<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Guns" tilewidth="111" tileheight="132" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="52" source="../Tiles/Tileset/Individual_PNGs/Level_Tileset/magazine2.png"/>
 </tile>
 <tile id="1">
  <image width="100" height="35" source="../Tiles/Tileset/Individual_PNGs/Level_Tileset/smg.png"/>
 </tile>
 <tile id="3">
  <image width="111" height="32" source="../Tiles/Tileset/Individual_PNGs/Level_Tileset/shotgun.png"/>
 </tile>
 <tile id="4">
  <image width="28" height="132" source="../Tiles/Tileset/Individual_PNGs/Level_Tileset/medium_bullet2.png"/>
 </tile>
</tileset>
